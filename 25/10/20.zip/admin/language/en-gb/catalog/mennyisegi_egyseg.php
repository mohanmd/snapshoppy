<?php
$_['entry_mennyisegi_egyseg']   = 'Amount Units';
