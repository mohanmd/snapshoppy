<?php
$_['text_mennyisegi_egyseg'] = 'Amount Units';
?>
